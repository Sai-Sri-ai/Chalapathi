//import logo from './logo.svg';
import './App.css';

import {Col,Container,Row,Button,Form} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.css'; 
import './index.css';
  

function App() {
  return (
<Container id='con'>
    <Row>
      <Col className='log'>
      <Form>
      <h2 id='lf'> LOGIN FORM </h2>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
      <Form.Label>Captcha</Form.Label>
        <Form.Control type="Captcha" placeholder="Captcha"  />
      </Form.Group>
      <Button variant="light" type="submit" id="lb">
        Submit
      </Button>
      </Form>
      </Col>
     <Col className='reg'>
      <Form>
       <h2 id='rf'> REGISTER FORM </h2>
       <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Name</Form.Label>
        <Form.Control type="name" placeholder="name" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email </Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Confirm Password</Form.Label>
        <Form.Control type="Confirm Password" placeholder="Confirm Password" />
      </Form.Group>
      <Button variant="light" type="submit" id='rb'>Register</Button>
      </Form>
      </Col>
    </Row>
</Container>
  );
}

export default App;
