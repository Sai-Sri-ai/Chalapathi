import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
//import reportWebVitals from './reportWebVitals';
/*
const container extends App{
  render();{
    return(
      <div className="from">
      <h2><u>LOGIN FORM</u></h2>
      <form id="loginform">
      Enter Name:<input type="text" placeholder="Username" required><br/>
      Enter Email: <input type="text" placeholder="email" required><br/>
      Password: <input type="password" placeholder="Password" required><br/>
                <button type="submit"class="log">Login</button>
            </form>
        </div>
      );
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
//reportWebVitals();
*/
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
